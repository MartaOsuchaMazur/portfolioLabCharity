
Przed przystąpieniem do pracy  przeczytaj poniższe wskazówki.
## Jak zacząć?

1. Zaimportuj projekt jako projekt `Maven`, wg poniższych wskazówek:

	* W `IntelliJ` wybieramy: `File –> New –> Project from Existing Sources...`
	* Wskazujemy lokalizację katalogu ze sklonowanym projektem i zatwierdzamy.
	* Następnie w nowym oknie wybieramy: `Import project from external model` i wskazujemy `Maven`
	* Wybieramy kolejno opcje: `Next –> Next –> Next –> Finish`
